<?php

/* 
 * Configuration du système
 */

// Configuration de la base de données

define("DSN", 'mysql:dbname=simentec_finalprojets;host=127.0.0.1');
define("USAGER", 'root');
define("MDP", '');
